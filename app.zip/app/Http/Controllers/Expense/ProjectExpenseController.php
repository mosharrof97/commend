<?php

namespace App\Http\Controllers\Expense;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProjectExpenseController extends Controller
{
    // public function __construct(){
    //     $this->middleware('permission:view expanse', ['only' => ['index']]);
    //     $this->middleware('permission:create expanse', ['only' => ['create','store']]);
    //     $this->middleware('permission:show expanse', ['only' => ['show']]);
    //     // $this->middleware('permission:delete', ['only' => ['delete']]);
    // }
    //
}
